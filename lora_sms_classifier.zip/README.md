# LoRA SMS Spam Classifier — MLX / Apple Silicon
# This model is TINY, this is to give you an idea of the process
# its not perfect, i take no liabity  :)  Its just fun :)  
# if you want use the scripts and use a bigger model you'll get better results
 

Fine-tunes **HuggingFaceTB/SmolLM2-135M** on the UCI SMS Spam dataset
using MLX LoRA, then evaluates with proper classification metrics.

## Quick start

```bash
chmod +x runme.sh
./runme.sh
```

The pipeline runs 7 steps end-to-end (~2–4 min on M1):

| Step | Script | What it does |
|------|--------|--------------|
| 1 | — | Install Python deps |
| 2 | `01_pull_model.py` | Download SmolLM2-135M from HuggingFace |
| 3 | `02_baseline_eval.py` | Evaluate baseline — loss, perplexity, accuracy |
| 4 | `03_download_data.py` | Download SMS Spam JSONL dataset |
| 5 | `04_retrain.py` | LoRA fine-tune (1000 iters, lr=5e-5) |
| 6 | `05_retrained_eval.py` | Evaluate retrained model (+ stress tests) |
| 7 | `06_compare_metrics.py` | Generate before/after comparison report |

## How accuracy is measured

**Correct method — label scoring:**  
For each example the model scores `log P(" spam" | prompt)` vs  
`log P(" not spam" | prompt)` and picks the higher one.  
This is true classification accuracy, not next-token prediction accuracy
over the entire sequence (which is meaningless for a classifier).

Both baseline and retrained use the **same 10 examples** so the
comparison is apples-to-apples. Stress-test examples are reported
separately in the retrained eval output.

## Interactive chat test

```bash
python scripts/09_chat_test.py
```

## Files

```
scripts/
  01_pull_model.py      Download model
  02_baseline_eval.py   Baseline evaluation (label-scoring accuracy)
  03_download_data.py   Download dataset
  04_retrain.py         LoRA fine-tuning (1000 iters)
  05_retrained_eval.py  Retrained evaluation (writes retrained_eval.json)
  06_compare_metrics.py Before/after comparison (reads both JSONs)
  07_predict_sms.py     Batch demo: baseline vs fine-tuned
  09_chat_test.py       Interactive spam filter

data/
  train.jsonl           ~800 training examples
  valid.jsonl           ~160 validation examples
  lora_config.json      LoRA hyperparameters (written by 04_retrain.py)

metrics/
  baseline_eval.txt / .json
  retrained_eval.txt / .json
  training_log.txt
  comparison_report.txt
```

## Requirements

- macOS, Apple Silicon (M1/M2/M3/M4)
- Python 3.10+
- See `requirements.txt`

## Held-out validation eval (the honest test)

Run this after `./runme.sh` to evaluate both models on all 160 examples
from `valid.jsonl` — data the model never saw during training:

```bash
python scripts/08_held_out_eval.py          # baseline + retrained, side-by-side
python scripts/08_held_out_eval.py --model retrained   # retrained only
python scripts/08_held_out_eval.py --model baseline    # baseline only
```

Reports accuracy, precision, recall, F1, confusion matrix, and all
misclassified examples. This is the number that actually matters —
not the 10-example in-distribution eval used for the pipeline comparison.
