#!/usr/bin/env python3
"""
05_retrained_eval.py
Evaluates the retrained (LoRA) model using the SAME eval set as baseline,
plus an additional stress-test set. Reports are always on the shared 10
examples so baseline vs retrained comparisons are apples-to-apples.

FIX 1: Accuracy is now true classification accuracy (label scoring), not
        next-token accuracy over all tokens.
FIX 2: Now writes retrained_eval.json so 06_compare_metrics.py reads
        fresh numbers instead of whatever was on disk from a prior run.
FIX 3: Eval set is identical to baseline for the main metrics; stress-test
        examples are reported separately so they don't skew the comparison.
"""

import math
import json
import time
from pathlib import Path
from datetime import datetime

RETRAINED_DIR = Path("models/retrained")
BASELINE_DIR  = Path("models/baseline")
METRICS_DIR   = Path("metrics")
OUTPUT_FILE   = METRICS_DIR / "retrained_eval.txt"

# ── MUST match 02_baseline_eval.py exactly for a valid comparison ─────────────
EVAL_EXAMPLES = [
    ("Classify the following SMS message as spam or not spam.\nMessage: Congratulations! You've won a FREE iPhone. Click here to claim now!\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Hi, are you coming to the party tonight?\nClassification:", "not spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: URGENT! Your account has been compromised. Call 0800-FREE now!\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Can you pick up some milk on your way home?\nClassification:", "not spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: You have won £1000 cash! To claim text WIN to 87121.\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Meeting is moved to 3pm today. Let me know if that works.\nClassification:", "not spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: FREE ringtones! Reply YES to get 10 free ringtones sent to your phone!\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Thanks for dinner last night, it was really great.\nClassification:", "not spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Claim your prize now! Text PRIZE to 80088. T&Cs apply.\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Running late, be there in 10 minutes.\nClassification:", "not spam"),
]

# Extra stress-test examples (not included in comparison metrics)
STRESS_EXAMPLES = [
    ("Classify the following SMS message as spam or not spam.\nMessage: Urgent: Action required on your account. Log in at http://bit.ly to avoid suspension.\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Did you win that money at the poker game last night? Let me know!\nClassification:", "not spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Your package was delivered and left at the front door — Mom\nClassification:", "not spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Hey it's Mike from earlier. I can get you 500 followers for $10 — Venmo me tonight\nClassification:", "spam"),
]


def label_log_prob(model, tokenizer, prompt_ids, label_ids):
    """Mean log P(label_ids | prompt_ids). Length-normalised."""
    import mlx.core as mx
    import numpy as np

    full = np.concatenate([prompt_ids[0], label_ids], axis=0)[None, :]
    full_ids = mx.array(full)

    x = full_ids[:, :-1]
    y = full_ids[:, 1:]

    logits    = model(x).astype(mx.float32)
    log_probs = logits - mx.logsumexp(logits, axis=-1, keepdims=True)

    label_len  = len(label_ids)
    prompt_len = prompt_ids.shape[1]
    start      = prompt_len - 1
    end        = start + label_len

    lp_label  = log_probs[0, start:end, :]
    y_label   = y[0, start:end]
    token_lps = lp_label[mx.arange(label_len), y_label]
    mx.eval(token_lps)
    return float(mx.mean(token_lps).item())


def compute_full_sequence_loss(model, tokenizer, texts):
    import mlx.core as mx

    total_loss = 0.0
    total_tok  = 0

    for text in texts:
        inp = tokenizer(text, return_tensors="np", truncation=True, max_length=256)
        ids = mx.array(inp["input_ids"])
        x, y = ids[:, :-1], ids[:, 1:]
        if x.shape[1] == 0:
            continue
        logits    = model(x).astype(mx.float32)
        log_probs = logits - mx.logsumexp(logits, axis=-1, keepdims=True)
        T         = x.shape[1]
        losses    = -log_probs[0][mx.arange(T), y[0]]
        mx.eval(losses)
        total_loss += float(mx.sum(losses).item())
        total_tok  += T

    avg_loss   = total_loss / max(total_tok, 1)
    perplexity = math.exp(min(avg_loss, 20))
    return avg_loss, perplexity


def compute_classification_accuracy(model, tokenizer, examples):
    correct = 0
    results = []

    for prompt_text, gt_label in examples:
        prompt_ids = tokenizer(
            prompt_text, return_tensors="np", truncation=True, max_length=256
        )["input_ids"]

        spam_ids     = tokenizer(" spam",     add_special_tokens=False)["input_ids"]
        not_spam_ids = tokenizer(" not spam", add_special_tokens=False)["input_ids"]

        lp_spam     = label_log_prob(model, tokenizer, prompt_ids, spam_ids)
        lp_not_spam = label_log_prob(model, tokenizer, prompt_ids, not_spam_ids)

        pred = "spam" if lp_spam > lp_not_spam else "not spam"
        ok   = (pred == gt_label)
        correct += int(ok)
        results.append((gt_label, pred, ok, lp_spam, lp_not_spam))

    accuracy = correct / len(examples) * 100
    return accuracy, results


def resolve_model_and_adapter():
    adapter_dir  = RETRAINED_DIR / "adapters"
    adapter_file = adapter_dir / "adapters.safetensors"
    fused        = RETRAINED_DIR / "fused"

    if adapter_file.exists():
        return str(BASELINE_DIR), str(adapter_dir), "adapter"
    elif fused.exists() and (fused / "config.json").exists():
        return str(fused), None, "fused"
    else:
        raise FileNotFoundError("Run 04_retrain.py first.")


def main():
    print("[05] Running retrained model evaluation …")
    METRICS_DIR.mkdir(parents=True, exist_ok=True)

    from mlx_lm import load
    from transformers import AutoTokenizer

    model_path, adapter_path, load_mode = resolve_model_and_adapter()
    tokenizer = AutoTokenizer.from_pretrained(str(BASELINE_DIR))

    load_kwargs = {}
    if adapter_path:
        load_kwargs["adapter_path"] = adapter_path

    model, _ = load(model_path, **load_kwargs)

    # ── Main eval (same set as baseline) ──────────────────────────────────────
    full_texts = [p + " " + l for p, l in EVAL_EXAMPLES]

    t0 = time.time()
    avg_loss, perplexity = compute_full_sequence_loss(model, tokenizer, full_texts)
    accuracy, clf_results = compute_classification_accuracy(model, tokenizer, EVAL_EXAMPLES)
    elapsed = time.time() - t0

    # ── Stress-test eval (reported separately, NOT written to JSON) ───────────
    _, stress_results = compute_classification_accuracy(model, tokenizer, STRESS_EXAMPLES)
    stress_correct = sum(1 for _, _, ok, _, _ in stress_results if ok)
    stress_acc     = stress_correct / len(STRESS_EXAMPLES) * 100

    # ── Write JSON (fixes stale-file bug) ─────────────────────────────────────
    result = {
        "timestamp"    : datetime.now().isoformat(),
        "load_mode"    : load_mode,
        "eval_loss"    : round(avg_loss, 4),
        "perplexity"   : round(perplexity, 4),
        "accuracy_pct" : round(accuracy, 2),
        "num_examples" : len(EVAL_EXAMPLES),
    }
    (METRICS_DIR / "retrained_eval.json").write_text(json.dumps(result, indent=2))

    # ── Human-readable report ─────────────────────────────────────────────────
    detail_lines = ["", "  Per-example classification results (main set):"]
    for gt, pred, ok, lp_s, lp_ns in clf_results:
        tick = "✓" if ok else "✗"
        detail_lines.append(
            f"    {tick}  gt={gt:<10}  pred={pred:<10}  "
            f"lp(spam)={lp_s:.3f}  lp(not spam)={lp_ns:.3f}"
        )

    stress_lines = ["", "  Stress-test results (not counted in comparison):"]
    for gt, pred, ok, lp_s, lp_ns in stress_results:
        tick = "✓" if ok else "✗"
        stress_lines.append(
            f"    {tick}  gt={gt:<10}  pred={pred:<10}  "
            f"lp(spam)={lp_s:.3f}  lp(not spam)={lp_ns:.3f}"
        )

    lines = [
        "=" * 60,
        "  Retrained Evaluation",
        "=" * 60,
        f"  Timestamp   : {result['timestamp']}",
        f"  Load mode   : {load_mode}",
        f"  Eval Loss   : {result['eval_loss']}  (causal-LM, full sequence)",
        f"  Perplexity  : {result['perplexity']}",
        f"  Accuracy    : {result['accuracy_pct']}%  (label scoring, {len(EVAL_EXAMPLES)} examples)",
        f"  Stress-test : {stress_acc:.1f}%  ({stress_correct}/{len(STRESS_EXAMPLES)} extra examples)",
    ] + detail_lines + stress_lines + ["=" * 60]

    OUTPUT_FILE.write_text("\n".join(lines) + "\n")

    print("\n".join(lines))
    print(f"[05] ✓ Metrics written to {OUTPUT_FILE}")
    print(f"[05] ✓ JSON written to metrics/retrained_eval.json")


if __name__ == "__main__":
    main()
