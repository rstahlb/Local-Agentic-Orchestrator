#!/usr/bin/env python3
"""
08_held_out_eval.py
Proper held-out evaluation using valid.jsonl — examples the model
never saw during training.

Runs label-scoring accuracy (log P("spam"|prompt) vs log P("not spam"|prompt))
on ALL 160 validation examples, for both the baseline and retrained model.
Reports accuracy, per-class breakdown, and a confusion matrix.

Usage:
    python scripts/08_held_out_eval.py
    python scripts/08_held_out_eval.py --model baseline
    python scripts/08_held_out_eval.py --model retrained
"""

import argparse
import json
import math
import time
from pathlib import Path
from datetime import datetime

BASELINE_DIR  = Path("models/baseline")
RETRAINED_DIR = Path("models/retrained")
VALID_JSONL   = Path("data/valid.jsonl")
METRICS_DIR   = Path("metrics")


# ── Data loading ──────────────────────────────────────────────────────────────

def load_valid_examples():
    """
    Parse valid.jsonl into (prompt, label) pairs.
    Prompt ends at "Classification:" — model predicts the label.
    """
    examples = []
    for line in VALID_JSONL.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        text = json.loads(line)["text"]
        # Find the last "Classification:" and split there
        split_key = "Classification:"
        idx = text.rfind(split_key)
        if idx == -1:
            continue
        prompt = text[: idx + len(split_key)]
        label_raw = text[idx + len(split_key) :].strip()
        # Normalise label
        if label_raw.startswith("not spam"):
            label = "not spam"
        elif label_raw.startswith("spam"):
            label = "spam"
        else:
            continue  # skip malformed
        examples.append((prompt, label))
    return examples


# ── Scoring ───────────────────────────────────────────────────────────────────

def label_log_prob(model, tokenizer, prompt_ids, label_ids):
    """Mean log P(label_ids | prompt_ids). Length-normalised."""
    import mlx.core as mx
    import numpy as np

    full = np.concatenate([prompt_ids[0], label_ids], axis=0)[None, :]
    full_ids = mx.array(full)
    x, y = full_ids[:, :-1], full_ids[:, 1:]

    logits    = model(x).astype(mx.float32)
    log_probs = logits - mx.logsumexp(logits, axis=-1, keepdims=True)

    label_len  = len(label_ids)
    prompt_len = prompt_ids.shape[1]
    start      = prompt_len - 1
    end        = start + label_len

    token_lps = log_probs[0, start:end, :][mx.arange(label_len), y[0, start:end]]
    mx.eval(token_lps)
    return float(mx.mean(token_lps).item())


def evaluate(model, tokenizer, examples):
    """
    Returns:
        accuracy    float  overall % correct
        results     list of (gt, pred, correct, lp_spam, lp_not_spam)
    """
    spam_ids     = tokenizer(" spam",     add_special_tokens=False)["input_ids"]
    not_spam_ids = tokenizer(" not spam", add_special_tokens=False)["input_ids"]

    correct = 0
    results = []
    n = len(examples)

    for i, (prompt_text, gt_label) in enumerate(examples):
        if (i + 1) % 20 == 0 or i == 0:
            print(f"    evaluating {i+1}/{n} …", flush=True)

        prompt_ids = tokenizer(
            prompt_text, return_tensors="np", truncation=True, max_length=256
        )["input_ids"]

        lp_spam     = label_log_prob(model, tokenizer, prompt_ids, spam_ids)
        lp_not_spam = label_log_prob(model, tokenizer, prompt_ids, not_spam_ids)

        pred = "spam" if lp_spam > lp_not_spam else "not spam"
        ok   = (pred == gt_label)
        correct += int(ok)
        results.append((gt_label, pred, ok, lp_spam, lp_not_spam))

    accuracy = correct / len(examples) * 100
    return accuracy, results


def confusion_matrix(results):
    """Returns (TP, FP, TN, FN) where positive = spam."""
    tp = fp = tn = fn = 0
    for gt, pred, _, _, _ in results:
        if gt == "spam"     and pred == "spam":     tp += 1
        if gt == "not spam" and pred == "spam":     fp += 1
        if gt == "not spam" and pred == "not spam": tn += 1
        if gt == "spam"     and pred == "not spam": fn += 1
    return tp, fp, tn, fn


def class_accuracy(results, label):
    subset = [(gt, pred, ok, s, ns) for gt, pred, ok, s, ns in results if gt == label]
    correct = sum(1 for _, _, ok, _, _ in subset if ok)
    return correct, len(subset)


# ── Model loading ─────────────────────────────────────────────────────────────

def load_model(which):
    from mlx_lm import load
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(str(BASELINE_DIR))

    if which == "baseline":
        model, _ = load(str(BASELINE_DIR))
        label = "Baseline (no fine-tuning)"
        tag   = "baseline"
    else:
        adapter_dir  = RETRAINED_DIR / "adapters"
        adapter_file = adapter_dir / "adapters.safetensors"
        fused        = RETRAINED_DIR / "fused"

        if adapter_file.exists():
            model, _ = load(str(BASELINE_DIR), adapter_path=str(adapter_dir))
            label = "Retrained (LoRA adapter)"
            tag   = "retrained_adapter"
        elif fused.exists() and (fused / "config.json").exists():
            model, _ = load(str(fused))
            label = "Retrained (fused)"
            tag   = "retrained_fused"
        else:
            raise FileNotFoundError("Run 04_retrain.py first.")

    return model, tokenizer, label, tag


# ── Report ────────────────────────────────────────────────────────────────────

def build_report(model_label, tag, examples, results, elapsed):
    accuracy, _ = (sum(1 for _, _, ok, _, _ in results if ok) / len(results) * 100, None)
    accuracy     = sum(1 for _, _, ok, _, _ in results if ok) / len(results) * 100
    tp, fp, tn, fn = confusion_matrix(results)
    spam_c, spam_n   = class_accuracy(results, "spam")
    ham_c,  ham_n    = class_accuracy(results, "not spam")

    precision = tp / (tp + fp) if (tp + fp) else 0
    recall    = tp / (tp + fn) if (tp + fn) else 0
    f1        = 2 * precision * recall / (precision + recall) if (precision + recall) else 0

    # Misclassified examples
    wrong = [(gt, pred, lp_s, lp_ns)
             for gt, pred, ok, lp_s, lp_ns in results if not ok]

    lines = [
        "=" * 64,
        f"  Held-Out Validation Eval — {model_label}",
        "=" * 64,
        f"  Timestamp    : {datetime.now().isoformat()}",
        f"  Dataset      : data/valid.jsonl  ({len(examples)} examples)",
        f"  Elapsed      : {elapsed:.1f}s",
        "",
        f"  Overall Accuracy  : {accuracy:.1f}%  ({sum(1 for _,_,ok,_,_ in results if ok)}/{len(results)})",
        f"  Spam Accuracy     : {spam_c/spam_n*100:.1f}%  ({spam_c}/{spam_n})   — recall",
        f"  Ham  Accuracy     : {ham_c/ham_n*100:.1f}%  ({ham_c}/{ham_n})   — specificity",
        "",
        f"  Precision  : {precision*100:.1f}%",
        f"  Recall     : {recall*100:.1f}%",
        f"  F1 Score   : {f1*100:.1f}%",
        "",
        "  Confusion Matrix (positive = spam):",
        f"    TP={tp}  FP={fp}",
        f"    FN={fn}  TN={tn}",
    ]

    if wrong:
        lines += ["", f"  Misclassified ({len(wrong)} examples):"]
        for gt, pred, lp_s, lp_ns in wrong[:20]:  # cap at 20
            lines.append(
                f"    gt={gt:<10} pred={pred:<10} "
                f"lp(spam)={lp_s:.3f}  lp(not spam)={lp_ns:.3f}"
            )
        if len(wrong) > 20:
            lines.append(f"    … and {len(wrong)-20} more")

    lines.append("=" * 64)
    return lines, {
        "timestamp"    : datetime.now().isoformat(),
        "model"        : tag,
        "num_examples" : len(examples),
        "accuracy_pct" : round(accuracy, 2),
        "spam_acc_pct" : round(spam_c / spam_n * 100, 2),
        "ham_acc_pct"  : round(ham_c  / ham_n  * 100, 2),
        "precision_pct": round(precision * 100, 2),
        "recall_pct"   : round(recall * 100, 2),
        "f1_pct"       : round(f1 * 100, 2),
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "elapsed_sec"  : round(elapsed, 1),
    }


# ── Main ─────────────────────────────────────────────────────────────────────

def run_eval(which):
    METRICS_DIR.mkdir(parents=True, exist_ok=True)

    print(f"[08] Loading {which} model …")
    model, tokenizer, model_label, tag = load_model(which)

    print(f"[08] Loading valid.jsonl …")
    examples = load_valid_examples()
    print(f"[08] {len(examples)} examples loaded ({sum(1 for _,l in examples if l=='spam')} spam, "
          f"{sum(1 for _,l in examples if l=='not spam')} ham)")

    print(f"[08] Running label-scoring eval …")
    t0 = time.time()
    accuracy, results = evaluate(model, tokenizer, examples)
    elapsed = time.time() - t0

    lines, result_dict = build_report(model_label, tag, examples, results, elapsed)

    out_txt  = METRICS_DIR / f"held_out_eval_{which}.txt"
    out_json = METRICS_DIR / f"held_out_eval_{which}.json"

    out_txt.write_text("\n".join(lines) + "\n")
    out_json.write_text(json.dumps(result_dict, indent=2))

    print("\n".join(lines))
    print(f"\n[08] ✓ Written to {out_txt}")

    return result_dict


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model",
        choices=["baseline", "retrained", "both"],
        default="both",
        help="Which model to evaluate (default: both)",
    )
    args = parser.parse_args()

    if args.model == "both":
        print("\n" + "=" * 64)
        print("  BASELINE")
        print("=" * 64)
        b = run_eval("baseline")

        print("\n" + "=" * 64)
        print("  RETRAINED")
        print("=" * 64)
        r = run_eval("retrained")

        # Side-by-side summary
        print("\n" + "=" * 64)
        print("  HEAD-TO-HEAD SUMMARY  (held-out valid.jsonl, 160 examples)")
        print("=" * 64)
        metrics = [
            ("Accuracy",  "accuracy_pct"),
            ("Precision", "precision_pct"),
            ("Recall",    "recall_pct"),
            ("F1 Score",  "f1_pct"),
            ("Spam Acc",  "spam_acc_pct"),
            ("Ham Acc",   "ham_acc_pct"),
        ]
        print(f"  {'Metric':<14} {'Baseline':>10} {'Retrained':>10} {'Delta':>10}")
        print("  " + "-" * 46)
        for label, key in metrics:
            bv = b[key]
            rv = r[key]
            delta = rv - bv
            sign  = "+" if delta >= 0 else ""
            print(f"  {label:<14} {bv:>9.1f}% {rv:>9.1f}% {sign}{delta:>8.1f}%")
        print("=" * 64 + "\n")
    else:
        run_eval(args.model)


if __name__ == "__main__":
    main()
