#!/usr/bin/env python3
"""
06_chat_test.py
Interactive script to test the fused spam detection model with custom user input.
"""

import mlx.core as mx
from mlx_lm import load, generate
from pathlib import Path

# Path to your Fused Model
MODEL_PATH = Path("models/retrained/fused")

def main():
    print(f"--- Loading Fused Model from {MODEL_PATH} ---")
    
    # Load the fused model and tokenizer
    try:
        model, tokenizer = load(str(MODEL_PATH))
    except Exception as e:
        print(f"Error loading model: {e}")
        print("Ensure you ran the fuse command in Step 04 first!")
        return

    print("\n--- SMS Spam Filter Ready ---")
    print("Type your message below (or type 'quit' to exit).")

    while True:
        user_input = input("\nSMS Message: ")
        
        if user_input.lower() in ['quit', 'exit', 'q']:
            break

        # Format the prompt exactly like the training data
        prompt = (
            f"Classify the following SMS message as spam or not spam.\n"
            f"Message: {user_input}\n"
            f"Classification:"
        )

        # Generate the response
        response = generate(
            model, 
            tokenizer, 
            prompt=prompt, 
            max_tokens=5, 
            verbose=False
        )

        print(f"AI Classification: {response.strip()}")

if __name__ == "__main__":
    main()
