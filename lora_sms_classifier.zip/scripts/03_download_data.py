#!/usr/bin/env python3
import json
import random
import sys
from pathlib import Path

# --- Configuration ---
DATA_DIR   = Path("data")
DATASET_ID = "sms_spam"
TRAIN_FILE = DATA_DIR / "train.jsonl"
VAL_FILE   = DATA_DIR / "valid.jsonl"
MAX_TRAIN  = 800
MAX_VAL    = 160

def format_example(row):
    label = "spam" if row["label"] == 1 else "not spam"
    text  = row["sms"].strip().replace("\n", " ")
    return {
        "text": (
            f"Classify the following SMS message as spam or not spam.\n"
            f"Message: {text}\n"
            f"Classification: {label}"
        )
    }

def main():
    # Force output to show up immediately
    print(f"[03] STARTING SCRIPT", flush=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    print(f"[03] Attempting to load '{DATASET_ID}' from Hugging Face...", flush=True)
    try:
        from datasets import load_dataset
        # This part can take 30-60 seconds depending on internet
        ds = load_dataset(DATASET_ID, split="train")
        print(f"[03] ✓ Dataset loaded! Total rows: {len(ds)}", flush=True)
    except Exception as e:
        print(f"[03] ✗ Error loading dataset: {e}", flush=True)
        return

    # Balancing logic
    spam = [row for row in ds if row["label"] == 1]
    ham  = [row for row in ds if row["label"] == 0]
    
    print(f"[03] Found {len(spam)} spam and {len(ham)} ham messages.", flush=True)

    num_train_per_class = MAX_TRAIN // 2 
    num_val_per_class   = MAX_VAL // 2

    # Check if we have enough data
    if len(spam) < (num_train_per_class + num_val_per_class):
        print(f"[03] ! Warning: Not enough spam. Using all {len(spam)} available.", flush=True)

    train_rows = spam[:num_train_per_class] + ham[:num_train_per_class]
    val_rows   = spam[num_train_per_class : num_train_per_class + num_val_per_class] + \
                 ham[num_train_per_class : num_train_per_class + num_val_per_class]

    train_examples = [format_example(row) for row in train_rows]
    val_examples   = [format_example(row) for row in val_rows]

    random.seed(42)
    random.shuffle(train_examples)
    random.shuffle(val_examples)

    def write_jsonl(path, rows):
        with open(path, "w") as f:
            for row in rows:
                f.write(json.dumps(row) + "\n")
        print(f"[03] ✓ Saved {len(rows)} rows to {path}", flush=True)

    write_jsonl(TRAIN_FILE, train_examples)
    write_jsonl(VAL_FILE,   val_examples)

    print("[03] COMPLETED SUCCESSFULLY", flush=True)

if __name__ == "__main__":
    main()
