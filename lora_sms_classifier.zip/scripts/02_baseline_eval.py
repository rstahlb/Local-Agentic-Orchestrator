#!/usr/bin/env python3
"""
02_baseline_eval.py
Evaluates the baseline (pre-fine-tuned) model on SMS spam examples.

FIX: Accuracy is now measured correctly — we compare log P("spam" | prompt)
vs log P("not spam" | prompt) at the label position and pick the higher one.
This is real classification accuracy, not next-token accuracy over all tokens.

Loss / perplexity are still computed over the full sequence (standard LM metric).
"""

import math
import json
import time
from pathlib import Path
from datetime import datetime

BASELINE_DIR = Path("models/baseline")
METRICS_DIR  = Path("metrics")
OUTPUT_FILE  = METRICS_DIR / "baseline_eval.txt"

# (prompt_without_label, ground_truth_label)
# Prompt ends at "Classification:" so the model predicts the label next.
EVAL_EXAMPLES = [
    ("Classify the following SMS message as spam or not spam.\nMessage: Congratulations! You've won a FREE iPhone. Click here to claim now!\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Hi, are you coming to the party tonight?\nClassification:", "not spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: URGENT! Your account has been compromised. Call 0800-FREE now!\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Can you pick up some milk on your way home?\nClassification:", "not spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: You have won £1000 cash! To claim text WIN to 87121.\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Meeting is moved to 3pm today. Let me know if that works.\nClassification:", "not spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: FREE ringtones! Reply YES to get 10 free ringtones sent to your phone!\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Thanks for dinner last night, it was really great.\nClassification:", "not spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Claim your prize now! Text PRIZE to 80088. T&Cs apply.\nClassification:", "spam"),
    ("Classify the following SMS message as spam or not spam.\nMessage: Running late, be there in 10 minutes.\nClassification:", "not spam"),
]


def label_log_prob(model, tokenizer, prompt_ids, label_ids):
    """
    Score mean log P(label_ids | prompt_ids).
    Runs one forward pass over prompt+label; reads log-probs at the
    label token positions only. Length-normalised so "not spam" (3 tokens)
    is comparable to "spam" (1 token).
    """
    import mlx.core as mx
    import numpy as np

    full = np.concatenate([prompt_ids[0], label_ids], axis=0)[None, :]
    full_ids = mx.array(full)

    x = full_ids[:, :-1]
    y = full_ids[:, 1:]

    logits    = model(x).astype(mx.float32)
    log_probs = logits - mx.logsumexp(logits, axis=-1, keepdims=True)

    label_len  = len(label_ids)
    prompt_len = prompt_ids.shape[1]
    start      = prompt_len - 1   # x-position where first label token is predicted
    end        = start + label_len

    lp_label = log_probs[0, start:end, :]
    y_label  = y[0, start:end]

    token_lps = lp_label[mx.arange(label_len), y_label]
    mx.eval(token_lps)
    return float(mx.mean(token_lps).item())


def compute_full_sequence_loss(model, tokenizer, texts):
    """Standard causal-LM loss & perplexity over full labelled sequences."""
    import mlx.core as mx

    total_loss = 0.0
    total_tok  = 0

    for text in texts:
        inp = tokenizer(text, return_tensors="np", truncation=True, max_length=256)
        ids = mx.array(inp["input_ids"])
        x, y = ids[:, :-1], ids[:, 1:]
        if x.shape[1] == 0:
            continue
        logits    = model(x).astype(mx.float32)
        log_probs = logits - mx.logsumexp(logits, axis=-1, keepdims=True)
        T         = x.shape[1]
        losses    = -log_probs[0][mx.arange(T), y[0]]
        mx.eval(losses)
        total_loss += float(mx.sum(losses).item())
        total_tok  += T

    avg_loss   = total_loss / max(total_tok, 1)
    perplexity = math.exp(min(avg_loss, 20))
    return avg_loss, perplexity


def compute_classification_accuracy(model, tokenizer, examples):
    """
    True classification accuracy via label scoring:
      predict = argmax over { log P(" spam"|prompt), log P(" not spam"|prompt) }
    """
    correct = 0
    results = []

    for prompt_text, gt_label in examples:
        prompt_ids = tokenizer(
            prompt_text, return_tensors="np", truncation=True, max_length=256
        )["input_ids"]

        # Leading space matches how the label appears after "Classification:"
        spam_ids     = tokenizer(" spam",     add_special_tokens=False)["input_ids"]
        not_spam_ids = tokenizer(" not spam", add_special_tokens=False)["input_ids"]

        lp_spam     = label_log_prob(model, tokenizer, prompt_ids, spam_ids)
        lp_not_spam = label_log_prob(model, tokenizer, prompt_ids, not_spam_ids)

        pred = "spam" if lp_spam > lp_not_spam else "not spam"
        ok   = (pred == gt_label)
        correct += int(ok)
        results.append((gt_label, pred, ok, lp_spam, lp_not_spam))

    accuracy = correct / len(examples) * 100
    return accuracy, results


def main():
    print("[02] Running baseline evaluation …")
    METRICS_DIR.mkdir(parents=True, exist_ok=True)

    from mlx_lm import load
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(str(BASELINE_DIR))
    model, _  = load(str(BASELINE_DIR))

    full_texts = [p + " " + l for p, l in EVAL_EXAMPLES]

    t0 = time.time()
    avg_loss, perplexity = compute_full_sequence_loss(model, tokenizer, full_texts)
    accuracy, clf_results = compute_classification_accuracy(model, tokenizer, EVAL_EXAMPLES)
    elapsed = time.time() - t0

    result = {
        "timestamp"    : datetime.now().isoformat(),
        "model"        : str(BASELINE_DIR),
        "stage"        : "baseline",
        "eval_loss"    : round(avg_loss, 4),
        "perplexity"   : round(perplexity, 4),
        "accuracy_pct" : round(accuracy, 2),
        "num_examples" : len(EVAL_EXAMPLES),
        "elapsed_sec"  : round(elapsed, 2),
    }

    detail_lines = ["", "  Per-example classification results:"]
    for gt, pred, ok, lp_s, lp_ns in clf_results:
        tick = "✓" if ok else "✗"
        detail_lines.append(
            f"    {tick}  gt={gt:<10}  pred={pred:<10}  "
            f"lp(spam)={lp_s:.3f}  lp(not spam)={lp_ns:.3f}"
        )

    lines = [
        "=" * 60,
        "  Baseline Evaluation — Before Fine-Tuning",
        "=" * 60,
        f"  Timestamp   : {result['timestamp']}",
        f"  Model       : {result['model']}",
        f"  Eval Loss   : {result['eval_loss']}  (causal-LM, full sequence)",
        f"  Perplexity  : {result['perplexity']}",
        f"  Accuracy    : {result['accuracy_pct']}%  (label scoring, true clf accuracy)",
        f"  Examples    : {result['num_examples']}",
        f"  Elapsed     : {result['elapsed_sec']}s",
    ] + detail_lines + ["=" * 60]

    OUTPUT_FILE.write_text("\n".join(lines) + "\n")
    (METRICS_DIR / "baseline_eval.json").write_text(json.dumps(result, indent=2))

    print("\n".join(lines))
    print(f"[02] ✓ Metrics written to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
