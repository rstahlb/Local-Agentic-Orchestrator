#!/usr/bin/env python3
"""
04_retrain.py
Fine-tunes the baseline model on the SMS spam dataset using mlx-lm LoRA.

FIX: Bumped iters from 400 → 1000 (roughly 5 epochs on 800 examples at
     batch-size 4) so the model has room to converge. Val loss was still
     trending down at iter 400, indicating under-training.
     max_length raised to 256 in eval scripts to match.
"""

import json
import subprocess
import sys
import time
from pathlib import Path

BASELINE_DIR  = Path("models/baseline")
RETRAINED_DIR = Path("models/retrained")
DATA_DIR      = Path("data")
METRICS_DIR   = Path("metrics")
TRAIN_LOG     = METRICS_DIR / "training_log.txt"

LORA_CONFIG = {
    "model"          : str(BASELINE_DIR),
    "train"          : True,
    "data"           : str(DATA_DIR),
    "seed"           : 42,
    "lora_layers"    : 16,
    "batch_size"     : 4,
    "iters"          : 1000,          # was 400 — model was still converging
    "val_batches"    : 10,
    "learning_rate"  : 5e-5,
    "steps_per_eval" : 100,
    "save_every"     : 250,
    "adapter_path"   : str(RETRAINED_DIR / "adapters"),
}

LORA_CONFIG_FILE = DATA_DIR / "lora_config.json"


def write_lora_config():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    LORA_CONFIG_FILE.write_text(json.dumps(LORA_CONFIG, indent=2))
    print(f"[04] LoRA config written to {LORA_CONFIG_FILE}")


def run_training():
    RETRAINED_DIR.mkdir(parents=True, exist_ok=True)
    (RETRAINED_DIR / "adapters").mkdir(parents=True, exist_ok=True)
    METRICS_DIR.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable, "-m", "mlx_lm", "lora",
        "--model",           str(BASELINE_DIR),
        "--train",
        "--data",            str(DATA_DIR),
        "--batch-size",      str(LORA_CONFIG["batch_size"]),
        "--iters",           str(LORA_CONFIG["iters"]),
        "--val-batches",     str(LORA_CONFIG["val_batches"]),
        "--learning-rate",   str(LORA_CONFIG["learning_rate"]),
        "--steps-per-eval",  str(LORA_CONFIG["steps_per_eval"]),
        "--save-every",      str(LORA_CONFIG["save_every"]),
        "--adapter-path",    str(RETRAINED_DIR / "adapters"),
        "--num-layers",      str(LORA_CONFIG["lora_layers"]),
        "--seed",            str(LORA_CONFIG["seed"]),
    ]

    print(f"[04] Starting fine-tuning ({LORA_CONFIG['iters']} steps, "
          f"lr={LORA_CONFIG['learning_rate']}) ...")
    print(f"[04] Command: {' '.join(cmd)}\n")

    log_lines = [
        f"Training run -- {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Command: {' '.join(cmd)}",
        "-" * 60,
    ]

    t0 = time.time()
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    for line in proc.stdout:
        line = line.rstrip()
        print(line)
        log_lines.append(line)

    proc.wait()
    elapsed = round(time.time() - t0, 1)

    log_lines.append("-" * 60)
    log_lines.append(f"Finished in {elapsed}s  |  Return code: {proc.returncode}")
    TRAIN_LOG.write_text("\n".join(log_lines) + "\n")

    if proc.returncode != 0:
        print(f"[04] Training failed (return code {proc.returncode}). Check {TRAIN_LOG}")
        sys.exit(proc.returncode)

    print(f"\n[04] Fine-tuning complete in {elapsed}s")
    print(f"[04] Adapters saved to {RETRAINED_DIR / 'adapters'}")
    print(f"[04] Training log  -> {TRAIN_LOG}")


def fuse_model():
    print("[04] Fusing LoRA adapters into base model ...")
    cmd = [
        sys.executable, "-m", "mlx_lm", "fuse",
        "--model",        str(BASELINE_DIR),
        "--adapter-path", str(RETRAINED_DIR / "adapters"),
        "--save-path",    str(RETRAINED_DIR / "fused"),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("[04] Fuse step failed (non-fatal). Eval will use adapter path instead.")
        print(result.stderr[-500:] if result.stderr else "")
        (RETRAINED_DIR / ".adapter_only").write_text("1")
    else:
        print(f"[04] Fused model saved to {RETRAINED_DIR / 'fused'}")


def main():
    write_lora_config()
    run_training()
    fuse_model()
    print("[04] Done")


if __name__ == "__main__":
    main()
