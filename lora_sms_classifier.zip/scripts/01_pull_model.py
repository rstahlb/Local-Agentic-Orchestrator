#!/usr/bin/env python3
"""
01_pull_model.py
Downloads SmolLM2-135M from Hugging Face Hub into models/baseline/
Small enough to fit in 16GB unified memory with room for fine-tuning.
"""

import os
import sys
from pathlib import Path

MODEL_ID = "HuggingFaceTB/SmolLM2-135M"
BASELINE_DIR = Path("models/baseline")

def main():
    print(f"[01] Pulling model: {MODEL_ID}")
    print(f"     Target dir  : {BASELINE_DIR}")

    BASELINE_DIR.mkdir(parents=True, exist_ok=True)

    try:
        from huggingface_hub import snapshot_download
        snapshot_download(
            repo_id=MODEL_ID,
            local_dir=str(BASELINE_DIR),
            ignore_patterns=["*.msgpack", "flax_model*", "tf_model*", "rust_model*"],
        )
        print(f"[01] ✓ Model downloaded to {BASELINE_DIR}")
    except Exception as e:
        print(f"[01] ✗ Failed to download model: {e}")
        sys.exit(1)

    # Write a marker file so later scripts know the model is ready
    marker = BASELINE_DIR / ".downloaded"
    marker.write_text(MODEL_ID)
    print("[01] ✓ Done")

if __name__ == "__main__":
    main()
