#!/usr/bin/env python3
"""
05_retrained_eval.py
Evaluates the retrained (LoRA) model using an expanded SMS spam test set.
Includes "Stress Test" messages to check for Overfitting vs. Generalization.
"""

import math
import json
import time
from pathlib import Path
from datetime import datetime

RETRAINED_DIR = Path("models/retrained")
BASELINE_DIR  = Path("models/baseline")
METRICS_DIR   = Path("metrics")
OUTPUT_FILE   = METRICS_DIR / "retrained_eval.txt"

# Updated EVAL_TEXTS with your new "Stress Test" messages at the end
EVAL_TEXTS = [
    "Classify the following SMS message as spam or not spam.\nMessage: Congratulations! You've won a FREE iPhone. Click here to claim now!\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Hi, are you coming to the party tonight?\nClassification: not spam",
    "Classify the following SMS message as spam or not spam.\nMessage: URGENT! Your account has been compromised. Call 0800-FREE now!\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Can you pick up some milk on your way home?\nClassification: not spam",
    "Classify the following SMS message as spam or not spam.\nMessage: You have won 1000 cash! To claim text WIN to 87121.\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Meeting is moved to 3pm today. Let me know if that works.\nClassification: not spam",
    "Classify the following SMS message as spam or not spam.\nMessage: FREE ringtones! Reply YES to get 10 free ringtones sent to your phone!\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Thanks for dinner last night, it was really great.\nClassification: not spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Claim your prize now! Text PRIZE to 80088. T&Cs apply.\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Running late, be there in 10 minutes.\nClassification: not spam",
    # --- STRESS TEST MESSAGES ---
    "Classify the following SMS message as spam or not spam.\nMessage: Urgent: Action required on your account. Log in at http://bit.ly to avoid suspension.\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Did you win that money at the poker game last night? Let me know!\nClassification: not spam",
]


def compute_metrics(model, tokenizer, texts):
    import mlx.core as mx

    total_loss_sum = 0.0
    total_tokens   = 0
    total_correct  = 0

    for text in texts:
        inputs    = tokenizer(text, return_tensors="np", truncation=True, max_length=128)
        input_ids = mx.array(inputs["input_ids"])

        x = input_ids[:, :-1]
        y = input_ids[:, 1:]

        if x.shape[1] == 0:
            continue

        logits = model(x)
        logits = logits.astype(mx.float32)

        log_probs = logits - mx.logsumexp(logits, axis=-1, keepdims=True)

        T       = x.shape[1]
        lp_flat = log_probs[0]
        y_flat  = y[0]

        token_losses = -lp_flat[mx.arange(T), y_flat]
        mx.eval(token_losses)

        preds   = mx.argmax(lp_flat, axis=-1)
        correct = mx.sum(preds == y_flat)
        mx.eval(preds, correct)

        total_loss_sum += float(mx.sum(token_losses).item())
        total_tokens   += T
        total_correct  += int(correct.item())

    avg_loss   = total_loss_sum / max(total_tokens, 1)
    perplexity = math.exp(min(avg_loss, 20))
    accuracy   = total_correct / max(total_tokens, 1) * 100
    return avg_loss, perplexity, accuracy


def resolve_model_and_adapter():
    adapter_dir  = RETRAINED_DIR / "adapters"
    adapter_file = adapter_dir / "adapters.safetensors"
    fused        = RETRAINED_DIR / "fused"

    if adapter_file.exists():
        return str(BASELINE_DIR), str(adapter_dir), "adapter"
    elif fused.exists() and (fused / "config.json").exists():
        return str(fused), None, "fused"
    else:
        raise FileNotFoundError("Run 04_retrain.py first.")


def main():
    print("[05] Running retrained model evaluation (Stress Test Enabled)...")
    METRICS_DIR.mkdir(parents=True, exist_ok=True)

    from mlx_lm import load
    from transformers import AutoTokenizer

    model_path, adapter_path, load_mode = resolve_model_and_adapter()
    tokenizer = AutoTokenizer.from_pretrained(str(BASELINE_DIR))

    load_kwargs = {}
    if adapter_path:
        load_kwargs["adapter_path"] = adapter_path

    model, _ = load(model_path, **load_kwargs)

    t0 = time.time()
    avg_loss, perplexity, accuracy = compute_metrics(model, tokenizer, EVAL_TEXTS)
    elapsed = time.time() - t0

    result = {
        "timestamp"   : datetime.now().isoformat(),
        "load_mode"   : load_mode,
        "eval_loss"   : round(avg_loss, 4),
        "perplexity"  : round(perplexity, 4),
        "accuracy_pct": round(accuracy, 2),
        "num_texts"   : len(EVAL_TEXTS),
    }

    lines = [
        "=" * 60,
        "  Retrained Evaluation -- STRESS TEST",
        "=" * 60,
        f"  Load mode   : {result['load_mode']}",
        f"  Eval Loss   : {result['eval_loss']} (Lower is better)",
        f"  Perplexity  : {result['perplexity']} (Confusion score)",
        f"  Accuracy    : {result['accuracy_pct']}%",
        f"  Texts used  : {result['num_texts']} (Includes Poker & Phishing)",
        "=" * 60,
    ]

    OUTPUT_FILE.write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
