#!/usr/bin/env python3
"""
02_baseline_eval.py
Evaluates the baseline (pre-fine-tuned) model on SMS spam examples.
Computes loss and perplexity, writes results to metrics/baseline_eval.txt.
"""

import math
import json
import time
from pathlib import Path
from datetime import datetime

BASELINE_DIR = Path("models/baseline")
METRICS_DIR  = Path("metrics")
OUTPUT_FILE  = METRICS_DIR / "baseline_eval.txt"

# SMS spam eval set — same domain as training data for a valid before/after comparison
EVAL_TEXTS = [
    "Classify the following SMS message as spam or not spam.\nMessage: Congratulations! You've won a FREE iPhone. Click here to claim now!\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Hi, are you coming to the party tonight?\nClassification: not spam",
    "Classify the following SMS message as spam or not spam.\nMessage: URGENT! Your account has been compromised. Call 0800-FREE now!\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Can you pick up some milk on your way home?\nClassification: not spam",
    "Classify the following SMS message as spam or not spam.\nMessage: You have won £1000 cash! To claim text WIN to 87121.\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Meeting is moved to 3pm today. Let me know if that works.\nClassification: not spam",
    "Classify the following SMS message as spam or not spam.\nMessage: FREE ringtones! Reply YES to get 10 free ringtones sent to your phone!\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Thanks for dinner last night, it was really great.\nClassification: not spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Claim your prize now! Text PRIZE to 80088. T&Cs apply.\nClassification: spam",
    "Classify the following SMS message as spam or not spam.\nMessage: Running late, be there in 10 minutes.\nClassification: not spam",
]

def compute_metrics(model, tokenizer, texts):
    import mlx.core as mx

    total_loss_sum = 0.0
    total_tokens   = 0
    total_correct  = 0

    for text in texts:
        inputs    = tokenizer(text, return_tensors="np", truncation=True, max_length=128)
        input_ids = mx.array(inputs["input_ids"])

        x = input_ids[:, :-1]
        y = input_ids[:, 1:]

        if x.shape[1] == 0:
            continue

        logits = model(x)
        logits = logits.astype(mx.float32)

        log_probs = logits - mx.logsumexp(logits, axis=-1, keepdims=True)

        T = x.shape[1]
        lp_flat  = log_probs[0]
        y_flat   = y[0]

        token_losses = -lp_flat[mx.arange(T), y_flat]
        mx.eval(token_losses)

        preds   = mx.argmax(lp_flat, axis=-1)
        correct = mx.sum(preds == y_flat)
        mx.eval(preds, correct)

        total_loss_sum += float(mx.sum(token_losses).item())
        total_tokens   += T
        total_correct  += int(correct.item())

    avg_loss   = total_loss_sum / max(total_tokens, 1)
    perplexity = math.exp(min(avg_loss, 20))
    accuracy   = total_correct / max(total_tokens, 1) * 100
    return avg_loss, perplexity, accuracy

def main():
    print("[02] Running baseline evaluation …")
    METRICS_DIR.mkdir(parents=True, exist_ok=True)

    try:
        from mlx_lm import load
        from transformers import AutoTokenizer
    except ImportError as e:
        print(f"[02] ✗ Import error: {e}")
        raise

    tokenizer = AutoTokenizer.from_pretrained(str(BASELINE_DIR))
    model, _  = load(str(BASELINE_DIR))
    model.eval() if hasattr(model, "eval") else None

    t0 = time.time()
    avg_loss, perplexity, accuracy = compute_metrics(model, tokenizer, EVAL_TEXTS)
    elapsed = time.time() - t0

    result = {
        "timestamp"   : datetime.now().isoformat(),
        "model"       : str(BASELINE_DIR),
        "stage"       : "baseline",
        "eval_loss"   : round(avg_loss, 4),
        "perplexity"  : round(perplexity, 4),
        "accuracy_pct": round(accuracy, 2),
        "num_texts"   : len(EVAL_TEXTS),
        "elapsed_sec" : round(elapsed, 2),
    }

    lines = [
        "=" * 60,
        "  Baseline Evaluation — Before Fine-Tuning",
        "=" * 60,
        f"  Timestamp   : {result['timestamp']}",
        f"  Model       : {result['model']}",
        f"  Eval Loss   : {result['eval_loss']}",
        f"  Perplexity  : {result['perplexity']}",
        f"  Accuracy    : {result['accuracy_pct']}%",
        f"  Texts used  : {result['num_texts']}",
        f"  Elapsed     : {result['elapsed_sec']}s",
        "=" * 60,
    ]

    OUTPUT_FILE.write_text("\n".join(lines) + "\n")
    (METRICS_DIR / "baseline_eval.json").write_text(json.dumps(result, indent=2))

    print("\n".join(lines))
    print(f"[02] ✓ Metrics written to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
