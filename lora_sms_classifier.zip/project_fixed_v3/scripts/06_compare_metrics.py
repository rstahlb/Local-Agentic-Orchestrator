#!/usr/bin/env python3
"""
06_compare_metrics.py
Reads baseline_eval.json and retrained_eval.json, computes deltas,
and writes a human-readable comparison_report.txt.
Exit code 0 = model improved, exit code 1 = model got worse.
"""

import json
import sys
from pathlib import Path
from datetime import datetime

METRICS_DIR  = Path("metrics")
BASELINE_JSON  = METRICS_DIR / "baseline_eval.json"
RETRAINED_JSON = METRICS_DIR / "retrained_eval.json"
REPORT_FILE    = METRICS_DIR / "comparison_report.txt"


def load_json(path):
    if not path.exists():
        print(f"[06] ✗ Missing metrics file: {path}")
        sys.exit(1)
    return json.loads(path.read_text())


def delta_str(before, after, lower_is_better=True):
    """Return formatted delta string with direction arrow."""
    diff = after - before
    pct  = (diff / abs(before)) * 100 if before != 0 else 0
    if lower_is_better:
        symbol = "✓" if diff < 0 else ("✗" if diff > 0 else "—")
    else:
        symbol = "✓" if diff > 0 else ("✗" if diff < 0 else "—")
    sign = "+" if diff >= 0 else ""
    return f"{sign}{pct:.1f}%  {symbol}"


def main():
    print("[06] Generating comparison report …")
    METRICS_DIR.mkdir(parents=True, exist_ok=True)

    b = load_json(BASELINE_JSON)
    r = load_json(RETRAINED_JSON)

    loss_delta  = delta_str(b["eval_loss"],    r["eval_loss"],    lower_is_better=True)
    ppl_delta   = delta_str(b["perplexity"],   r["perplexity"],   lower_is_better=True)
    acc_delta   = delta_str(b["accuracy_pct"], r["accuracy_pct"], lower_is_better=False)

    improved = (r["eval_loss"] < b["eval_loss"])

    verdict = "Model IS SMARTER after retraining.  ✓" if improved else \
              "Model did NOT improve — check training config or increase iters."

    lines = [
        "=" * 62,
        "  MLOps Pipeline — Before vs After Retraining",
        "=" * 62,
        f"  Generated    : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        f"  {'Metric':<20} {'Baseline':>12} {'Retrained':>12} {'Delta':>14}",
        "  " + "-" * 58,
        f"  {'Eval Loss':<20} {b['eval_loss']:>12.4f} {r['eval_loss']:>12.4f} {loss_delta:>14}",
        f"  {'Perplexity':<20} {b['perplexity']:>12.4f} {r['perplexity']:>12.4f} {ppl_delta:>14}",
        f"  {'Accuracy':<20} {b['accuracy_pct']:>11.2f}% {r['accuracy_pct']:>11.2f}% {acc_delta:>14}",
        "  " + "-" * 58,
        "",
        f"  {verdict}",
        "",
        "  Baseline  timestamp : " + b["timestamp"],
        "  Retrained timestamp : " + r["timestamp"],
        "=" * 62,
    ]

    REPORT_FILE.write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    print(f"\n[06] ✓ Report written to {REPORT_FILE}")

    sys.exit(0 if improved else 2)


if __name__ == "__main__":
    main()
