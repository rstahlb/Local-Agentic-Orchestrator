# MLOps Local Pipeline — Apple Silicon / MLX
### v3 (fixed)

End-to-end MLOps demo: download → evaluate → fine-tune → re-evaluate → compare.

## What it does

| Step | Script | Action |
|------|--------|--------|
| 1 | `01_pull_model.py` | Download SmolLM2-135M from HuggingFace |
| 2 | `02_baseline_eval.py` | Eval baseline: loss / perplexity / accuracy |
| 3 | `03_download_data.py` | Download sms_spam dataset (800 train / 160 val) |
| 4 | `04_retrain.py` | LoRA fine-tune with MLX (600 iters, cosine LR) |
| 5 | `05_retrained_eval.py` | Eval retrained model |
| 6 | `06_compare_metrics.py` | Generate before/after comparison report |

## Usage

```bash
chmod +x runme.sh
./runme.sh
```

Requires Python 3.10+ and Apple Silicon (M1/M2/M3/M4). Run `pip install -r requirements.txt` if running scripts individually.

## Fixes in v3 (vs v2)

| Issue | Fix |
|-------|-----|
| Loss exploded to 11.5 at iter 50 | LR lowered from `1e-3` → `2e-5` |
| No LR decay | Added `cosine_decay` schedule |
| Unstable early training | Added 60-step warmup |
| Only 300 iters on 400 examples | 600 iters on 800 examples |
| `"Validation set not found"` warning | Renamed `val.jsonl` → `valid.jsonl` (required by mlx-lm) |
| Deprecated `python -m mlx_lm.lora` | Updated to `python -m mlx_lm lora` |
| `trust_remote_code` deprecation | Removed (sms_spam doesn't need it) |
| Fused model evaluated worse | Eval now loads base + adapter directly |
