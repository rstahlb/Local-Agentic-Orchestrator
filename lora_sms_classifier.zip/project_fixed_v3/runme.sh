#!/usr/bin/env bash
# =============================================================================
#  runme.sh — MLOps Local Pipeline
#  Apple Silicon / MLX | Hugging Face | LoRA fine-tuning
#
#  Usage: ./runme.sh
#
#  Runs the full pipeline:
#    1. Install Python dependencies
#    2. Pull baseline model from Hugging Face
#    3. Evaluate baseline → metrics/baseline_eval.txt
#    4. Download fine-tuning dataset from Hugging Face
#    5. Fine-tune model with MLX LoRA
#    6. Evaluate retrained model → metrics/retrained_eval.txt
#    7. Generate comparison report → metrics/comparison_report.txt
#
#  BONUS:
#    • Run step 7 manually: python scripts/07_predict_sms.py
#    • Interactive mode: python scripts/07_predict_sms.py --interactive
#    • React demo: See SMS_Spam_Demo.jsx for interactive web UI
# =============================================================================

set -euo pipefail

# ── Colours ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GRN='\033[0;32m'
YLW='\033[1;33m'
BLU='\033[1;34m'
CYN='\033[0;36m'
RST='\033[0m'

STEP=0
total_steps=7

step() {
    STEP=$((STEP + 1))
    echo ""
    echo -e "${BLU}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RST}"
    echo -e "${YLW}  Step ${STEP}/${total_steps}: $1${RST}"
    echo -e "${BLU}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RST}"
}

ok()   { echo -e "${GRN}  ✓ $1${RST}"; }
fail() { echo -e "${RED}  ✗ $1${RST}"; exit 1; }
info() { echo -e "${CYN}  → $1${RST}"; }

# ── Header ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${YLW}╔══════════════════════════════════════════════════════════════╗${RST}"
echo -e "${YLW}║        MLOps Local Pipeline  —  Apple Silicon / MLX         ║${RST}"
echo -e "${YLW}╚══════════════════════════════════════════════════════════════╝${RST}"
echo ""
info "Pipeline start: $(date)"
info "Working dir   : $(pwd)"

# ── Sanity checks ─────────────────────────────────────────────────────────────
if [[ "$(uname -m)" != "arm64" ]]; then
    echo -e "${YLW}  ⚠ Warning: not running on Apple Silicon. MLX may not be available.${RST}"
fi

# ── Step 1: Install dependencies ─────────────────────────────────────────────
step "Install Python dependencies"
if ! command -v python3 &>/dev/null; then
    fail "python3 not found. Install via Homebrew: brew install python"
fi
PYTHON="python3"
info "Python: $($PYTHON --version)"
$PYTHON -m pip install --quiet --upgrade pip 2>&1 || true
$PYTHON -m pip install --quiet -r requirements.txt 2>&1 || { fail "pip install failed"; }
ok "Dependencies installed"

# ── Step 2: Pull model ────────────────────────────────────────────────────────
step "Pull baseline model (HuggingFaceTB/SmolLM2-135M)"
if [[ -f "models/baseline/.downloaded" ]]; then
    info "Model already downloaded — skipping pull"
else
    $PYTHON scripts/01_pull_model.py || fail "Model pull failed"
fi
ok "Baseline model ready"

# ── Step 3: Baseline evaluation ───────────────────────────────────────────────
step "Evaluate baseline model"
$PYTHON scripts/02_baseline_eval.py || fail "Baseline evaluation failed"
ok "Baseline metrics written to metrics/baseline_eval.txt"

# ── Step 4: Download dataset ─────────────────────────────────────────────────
step "Download fine-tuning dataset (sms_spam)"
if [[ -f "data/train.jsonl" && -f "data/valid.jsonl" ]]; then
    info "Dataset already downloaded — skipping"
else
    $PYTHON scripts/03_download_data.py || fail "Dataset download failed"
fi
ok "Dataset ready in data/"

# ── Step 5: Fine-tune ─────────────────────────────────────────────────────────
step "Fine-tune model (MLX LoRA, 600 steps, lr=2e-5, cosine)"
$PYTHON scripts/04_retrain.py || fail "Fine-tuning failed"
ok "Fine-tuning complete — adapters saved to models/retrained/"

# ── Step 6: Retrained evaluation ──────────────────────────────────────────────
step "Evaluate retrained model"
$PYTHON scripts/05_retrained_eval.py || fail "Retrained evaluation failed"
ok "Retrained metrics written to metrics/retrained_eval.txt"

# ── Step 7: Comparison report ─────────────────────────────────────────────────
step "Generate comparison report"
$PYTHON scripts/06_compare_metrics.py || COMPARE_EXIT=$?
COMPARE_EXIT=${COMPARE_EXIT:-0}

# ── Footer ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${YLW}╔══════════════════════════════════════════════════════════════╗${RST}"
echo -e "${YLW}║                     Pipeline Complete                       ║${RST}"
echo -e "${YLW}╚══════════════════════════════════════════════════════════════╝${RST}"
echo ""
echo -e "${CYN}  Metrics files:${RST}"
echo "    metrics/baseline_eval.txt"
echo "    metrics/retrained_eval.txt"
echo "    metrics/training_log.txt"
echo "    metrics/comparison_report.txt"
echo ""

if [[ $COMPARE_EXIT -eq 0 ]]; then
    echo -e "${GRN}  ✓ Model improved after retraining!${RST}"
elif [[ $COMPARE_EXIT -eq 2 ]]; then
    echo -e "${YLW}  ⚠ Model did not improve — try increasing --iters in 04_retrain.py${RST}"
fi

echo ""
info "Pipeline end: $(date)"
